//: # Assignment 1
//: -https://projecteuler.net/problem=1

func  multOf3and5(range:Int = 1000) ->Int
{
    var sum:Int=0

    for i in 0..<range
    {
    
        if(i%3==0 || i%5==0)
        {
            sum = sum + i
        }
    
    }
    //print("The sum is \(sum)")
    return sum
}

multOf3and5()

//: -https://projecteuler.net/problem=2

func evenFib(end:Int = 10) ->Int
{
    var total:Int = 0
    var prev:Int = 0
    var curr:Int = 1
    var next:Int
    
    for f in 0...end
    {
        if(f<=1)
        {
            next = f
        }
        else
        {
            next = prev + curr
            prev = curr
            curr = next
            if(next%2==0)
            {
                total += next
                
            }
        }
        
    }
    print("The total is \(total)")
    return total
}

evenFib()